







<!doctype html>
<html>
  <head>
    
  
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/static/css/debian.css" />
    <link rel="stylesheet" type="text/css"
          href="/static/css/base.css" />
    <link rel="shortcut icon"
          href="/static/favicon.ico" />
    <title>File: rng.h | Debian sources</title>
    

  <link rel="stylesheet"
        href="/javascript/highlight/styles/googlecode.css">
  <script src="/javascript/highlight/highlight.pack.js"></script>
  <link rel="stylesheet" type="text/css"
        href="/static/css/source_file.css" />


  </head>
  <body>
    <header id="header">
      <div id="upperheader">
        <div id="logo">
          <a href="http://debian.org" title="Debian Home"><img src="/static/img/debian-50.png" alt="Debian"></a>
        </div> <!-- end logo -->
        <p class="section"><a href="/">Debsources</a></p>
	<div id="searchbox">
	    <form action="/search/" name="searchform"
        method="post" style="display: inline;">
      <input id="query-1" name="query" placeholder="package name" type="text" value="">
    
    
    <input type="submit" value="Search package" />
  </form>
	    <form name="codesearch" method="get"
		  action="http://codesearch.debian.net/search">
	      <input name="q" value="package:dds "
		     type="text" />
	      <input type="submit" value="Search code" />
	    </form>
	</div>   <!-- end sitetools -->
      </div> <!-- end upperheader -->
      <!--UdmComment-->
      <nav id="navbar">
        <p class="hidecss"><a href="#content">Skip Quicknav</a></p>
        <ul>
          <li><a href="/">Home</a></li>
          <li><a href="/advancedsearch/">Search</a></li>
          <li><a href="/doc/">Documentation</a></li>
          <li><a href="/stats/">Stats</a></li>
          <li><a href="/about/">About</a></li>
        </ul>
      </nav> <!-- end navbar -->
      <p id="breadcrumbs">source / <a href="/src/dds">dds</a> / <a href="/src/dds/2.5.2%2Bddd105-1">2.5.2+ddd105-1</a> / <a href="/src/dds/2.5.2%2Bddd105-1/ddd">ddd</a> / rng.h</p>
    </header> <!-- end header -->
    
    <div id="content">
      


<h2>File: rng.h</h2>



<script type="text/javascript">
    function toggle(id)
    {
    var elem = document.getElementById(id);
    if(elem.style.display == "none")
      elem.style.display = "block";
    else
      elem.style.display = "none";
    }
  </script>


<div id="pkginfobox" class="pkginfobox_fixed">

  
  <span onclick="toggle('infobox_content')">package info
    <small>(click to toggle)</small></span>
  
  <div id="infobox_content">
    
    <em>dds 2.5.2+ddd105-1</em>
    
    <ul>
      <li>links:
	<a href="http://packages.qa.debian.org/dds"><abbr title="Debian Package Tracking
							   System">PTS</abbr></a>,
	<a href="http://svn.df7cb.de/bridge/dds/trunk"><abbr title="Version Control System">VCS</abbr></a>
	</li>
      <li>area: main</li>
      <li>in suites: jessie, sid</li>
      
        <li>size: 1,552 kB</li>
      
      
        <li><abbr title="source lines of code">sloc</abbr>:
	  
            
              cpp: 8,945; 
            
              ansic: 281; 
            
              python: 89; 
            
              makefile: 87
            
	  
        </li>
      
    </ul>
  </div>
</div>


<table id="file_metadata">
  <tr>
    <td>
    file content (255 lines)
    | permissions: rw-r--r--
    </td>
    <td style="text-align: right;">
    <a href="/src/dds/2.5.2%2Bddd105-1/ddd">parent folder</a>
    | <a href="/data/main/d/dds/2.5.2+ddd105-1/ddd/rng.h">download</a>
    
    | <a href="/sha256/?checksum=2ad20181bd8bd776efac010d76ed010867f04e6d25a20981f4e6c36dcf751cf1&amp;page=1">
	  duplicates (4)</a>
    
    </td>
  </tr>
</table>

<table id="codetable">
  <tr>
    <td>
      <pre id="sourceslinenumbers"><a id="L1" href="#L1">1</a><br /><a id="L2" href="#L2">2</a><br /><a id="L3" href="#L3">3</a><br /><a id="L4" href="#L4">4</a><br /><a id="L5" href="#L5">5</a><br /><a id="L6" href="#L6">6</a><br /><a id="L7" href="#L7">7</a><br /><a id="L8" href="#L8">8</a><br /><a id="L9" href="#L9">9</a><br /><a id="L10" href="#L10">10</a><br /><a id="L11" href="#L11">11</a><br /><a id="L12" href="#L12">12</a><br /><a id="L13" href="#L13">13</a><br /><a id="L14" href="#L14">14</a><br /><a id="L15" href="#L15">15</a><br /><a id="L16" href="#L16">16</a><br /><a id="L17" href="#L17">17</a><br /><a id="L18" href="#L18">18</a><br /><a id="L19" href="#L19">19</a><br /><a id="L20" href="#L20">20</a><br /><a id="L21" href="#L21">21</a><br /><a id="L22" href="#L22">22</a><br /><a id="L23" href="#L23">23</a><br /><a id="L24" href="#L24">24</a><br /><a id="L25" href="#L25">25</a><br /><a id="L26" href="#L26">26</a><br /><a id="L27" href="#L27">27</a><br /><a id="L28" href="#L28">28</a><br /><a id="L29" href="#L29">29</a><br /><a id="L30" href="#L30">30</a><br /><a id="L31" href="#L31">31</a><br /><a id="L32" href="#L32">32</a><br /><a id="L33" href="#L33">33</a><br /><a id="L34" href="#L34">34</a><br /><a id="L35" href="#L35">35</a><br /><a id="L36" href="#L36">36</a><br /><a id="L37" href="#L37">37</a><br /><a id="L38" href="#L38">38</a><br /><a id="L39" href="#L39">39</a><br /><a id="L40" href="#L40">40</a><br /><a id="L41" href="#L41">41</a><br /><a id="L42" href="#L42">42</a><br /><a id="L43" href="#L43">43</a><br /><a id="L44" href="#L44">44</a><br /><a id="L45" href="#L45">45</a><br /><a id="L46" href="#L46">46</a><br /><a id="L47" href="#L47">47</a><br /><a id="L48" href="#L48">48</a><br /><a id="L49" href="#L49">49</a><br /><a id="L50" href="#L50">50</a><br /><a id="L51" href="#L51">51</a><br /><a id="L52" href="#L52">52</a><br /><a id="L53" href="#L53">53</a><br /><a id="L54" href="#L54">54</a><br /><a id="L55" href="#L55">55</a><br /><a id="L56" href="#L56">56</a><br /><a id="L57" href="#L57">57</a><br /><a id="L58" href="#L58">58</a><br /><a id="L59" href="#L59">59</a><br /><a id="L60" href="#L60">60</a><br /><a id="L61" href="#L61">61</a><br /><a id="L62" href="#L62">62</a><br /><a id="L63" href="#L63">63</a><br /><a id="L64" href="#L64">64</a><br /><a id="L65" href="#L65">65</a><br /><a id="L66" href="#L66">66</a><br /><a id="L67" href="#L67">67</a><br /><a id="L68" href="#L68">68</a><br /><a id="L69" href="#L69">69</a><br /><a id="L70" href="#L70">70</a><br /><a id="L71" href="#L71">71</a><br /><a id="L72" href="#L72">72</a><br /><a id="L73" href="#L73">73</a><br /><a id="L74" href="#L74">74</a><br /><a id="L75" href="#L75">75</a><br /><a id="L76" href="#L76">76</a><br /><a id="L77" href="#L77">77</a><br /><a id="L78" href="#L78">78</a><br /><a id="L79" href="#L79">79</a><br /><a id="L80" href="#L80">80</a><br /><a id="L81" href="#L81">81</a><br /><a id="L82" href="#L82">82</a><br /><a id="L83" href="#L83">83</a><br /><a id="L84" href="#L84">84</a><br /><a id="L85" href="#L85">85</a><br /><a id="L86" href="#L86">86</a><br /><a id="L87" href="#L87">87</a><br /><a id="L88" href="#L88">88</a><br /><a id="L89" href="#L89">89</a><br /><a id="L90" href="#L90">90</a><br /><a id="L91" href="#L91">91</a><br /><a id="L92" href="#L92">92</a><br /><a id="L93" href="#L93">93</a><br /><a id="L94" href="#L94">94</a><br /><a id="L95" href="#L95">95</a><br /><a id="L96" href="#L96">96</a><br /><a id="L97" href="#L97">97</a><br /><a id="L98" href="#L98">98</a><br /><a id="L99" href="#L99">99</a><br /><a id="L100" href="#L100">100</a><br /><a id="L101" href="#L101">101</a><br /><a id="L102" href="#L102">102</a><br /><a id="L103" href="#L103">103</a><br /><a id="L104" href="#L104">104</a><br /><a id="L105" href="#L105">105</a><br /><a id="L106" href="#L106">106</a><br /><a id="L107" href="#L107">107</a><br /><a id="L108" href="#L108">108</a><br /><a id="L109" href="#L109">109</a><br /><a id="L110" href="#L110">110</a><br /><a id="L111" href="#L111">111</a><br /><a id="L112" href="#L112">112</a><br /><a id="L113" href="#L113">113</a><br /><a id="L114" href="#L114">114</a><br /><a id="L115" href="#L115">115</a><br /><a id="L116" href="#L116">116</a><br /><a id="L117" href="#L117">117</a><br /><a id="L118" href="#L118">118</a><br /><a id="L119" href="#L119">119</a><br /><a id="L120" href="#L120">120</a><br /><a id="L121" href="#L121">121</a><br /><a id="L122" href="#L122">122</a><br /><a id="L123" href="#L123">123</a><br /><a id="L124" href="#L124">124</a><br /><a id="L125" href="#L125">125</a><br /><a id="L126" href="#L126">126</a><br /><a id="L127" href="#L127">127</a><br /><a id="L128" href="#L128">128</a><br /><a id="L129" href="#L129">129</a><br /><a id="L130" href="#L130">130</a><br /><a id="L131" href="#L131">131</a><br /><a id="L132" href="#L132">132</a><br /><a id="L133" href="#L133">133</a><br /><a id="L134" href="#L134">134</a><br /><a id="L135" href="#L135">135</a><br /><a id="L136" href="#L136">136</a><br /><a id="L137" href="#L137">137</a><br /><a id="L138" href="#L138">138</a><br /><a id="L139" href="#L139">139</a><br /><a id="L140" href="#L140">140</a><br /><a id="L141" href="#L141">141</a><br /><a id="L142" href="#L142">142</a><br /><a id="L143" href="#L143">143</a><br /><a id="L144" href="#L144">144</a><br /><a id="L145" href="#L145">145</a><br /><a id="L146" href="#L146">146</a><br /><a id="L147" href="#L147">147</a><br /><a id="L148" href="#L148">148</a><br /><a id="L149" href="#L149">149</a><br /><a id="L150" href="#L150">150</a><br /><a id="L151" href="#L151">151</a><br /><a id="L152" href="#L152">152</a><br /><a id="L153" href="#L153">153</a><br /><a id="L154" href="#L154">154</a><br /><a id="L155" href="#L155">155</a><br /><a id="L156" href="#L156">156</a><br /><a id="L157" href="#L157">157</a><br /><a id="L158" href="#L158">158</a><br /><a id="L159" href="#L159">159</a><br /><a id="L160" href="#L160">160</a><br /><a id="L161" href="#L161">161</a><br /><a id="L162" href="#L162">162</a><br /><a id="L163" href="#L163">163</a><br /><a id="L164" href="#L164">164</a><br /><a id="L165" href="#L165">165</a><br /><a id="L166" href="#L166">166</a><br /><a id="L167" href="#L167">167</a><br /><a id="L168" href="#L168">168</a><br /><a id="L169" href="#L169">169</a><br /><a id="L170" href="#L170">170</a><br /><a id="L171" href="#L171">171</a><br /><a id="L172" href="#L172">172</a><br /><a id="L173" href="#L173">173</a><br /><a id="L174" href="#L174">174</a><br /><a id="L175" href="#L175">175</a><br /><a id="L176" href="#L176">176</a><br /><a id="L177" href="#L177">177</a><br /><a id="L178" href="#L178">178</a><br /><a id="L179" href="#L179">179</a><br /><a id="L180" href="#L180">180</a><br /><a id="L181" href="#L181">181</a><br /><a id="L182" href="#L182">182</a><br /><a id="L183" href="#L183">183</a><br /><a id="L184" href="#L184">184</a><br /><a id="L185" href="#L185">185</a><br /><a id="L186" href="#L186">186</a><br /><a id="L187" href="#L187">187</a><br /><a id="L188" href="#L188">188</a><br /><a id="L189" href="#L189">189</a><br /><a id="L190" href="#L190">190</a><br /><a id="L191" href="#L191">191</a><br /><a id="L192" href="#L192">192</a><br /><a id="L193" href="#L193">193</a><br /><a id="L194" href="#L194">194</a><br /><a id="L195" href="#L195">195</a><br /><a id="L196" href="#L196">196</a><br /><a id="L197" href="#L197">197</a><br /><a id="L198" href="#L198">198</a><br /><a id="L199" href="#L199">199</a><br /><a id="L200" href="#L200">200</a><br /><a id="L201" href="#L201">201</a><br /><a id="L202" href="#L202">202</a><br /><a id="L203" href="#L203">203</a><br /><a id="L204" href="#L204">204</a><br /><a id="L205" href="#L205">205</a><br /><a id="L206" href="#L206">206</a><br /><a id="L207" href="#L207">207</a><br /><a id="L208" href="#L208">208</a><br /><a id="L209" href="#L209">209</a><br /><a id="L210" href="#L210">210</a><br /><a id="L211" href="#L211">211</a><br /><a id="L212" href="#L212">212</a><br /><a id="L213" href="#L213">213</a><br /><a id="L214" href="#L214">214</a><br /><a id="L215" href="#L215">215</a><br /><a id="L216" href="#L216">216</a><br /><a id="L217" href="#L217">217</a><br /><a id="L218" href="#L218">218</a><br /><a id="L219" href="#L219">219</a><br /><a id="L220" href="#L220">220</a><br /><a id="L221" href="#L221">221</a><br /><a id="L222" href="#L222">222</a><br /><a id="L223" href="#L223">223</a><br /><a id="L224" href="#L224">224</a><br /><a id="L225" href="#L225">225</a><br /><a id="L226" href="#L226">226</a><br /><a id="L227" href="#L227">227</a><br /><a id="L228" href="#L228">228</a><br /><a id="L229" href="#L229">229</a><br /><a id="L230" href="#L230">230</a><br /><a id="L231" href="#L231">231</a><br /><a id="L232" href="#L232">232</a><br /><a id="L233" href="#L233">233</a><br /><a id="L234" href="#L234">234</a><br /><a id="L235" href="#L235">235</a><br /><a id="L236" href="#L236">236</a><br /><a id="L237" href="#L237">237</a><br /><a id="L238" href="#L238">238</a><br /><a id="L239" href="#L239">239</a><br /><a id="L240" href="#L240">240</a><br /><a id="L241" href="#L241">241</a><br /><a id="L242" href="#L242">242</a><br /><a id="L243" href="#L243">243</a><br /><a id="L244" href="#L244">244</a><br /><a id="L245" href="#L245">245</a><br /><a id="L246" href="#L246">246</a><br /><a id="L247" href="#L247">247</a><br /><a id="L248" href="#L248">248</a><br /><a id="L249" href="#L249">249</a><br /><a id="L250" href="#L250">250</a><br /><a id="L251" href="#L251">251</a><br /><a id="L252" href="#L252">252</a><br /><a id="L253" href="#L253">253</a><br /><a id="L254" href="#L254">254</a><br /><a id="L255" href="#L255">255</a><br /></pre>
    </td>
    <td>
      <pre><code id="sourcecode" class="cpp">// =============================================================================
/* rng.cpp  RNG - random number generators

            PMC 14-jun-2005
            PMC 10-jul-2005
            PMC 13-Jul-2006 updated, default is now MT

   Copyright 2005-2006 P.M.Cronje

   RNG is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   RNG is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with RNG; if not, write to the Free Software
   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

*/
// =============================================================================

#ifndef RNG_H
#define RNG_H

typedef unsigned long long uint64;

// -----------------------------------------------------------------------------
// Entropy test
// -----------------------------------------------------------------------------

void initEnt(bool binmode);
void addEnt(unsigned char *buf, int buflen);
void endEnt(double *r_ent, double *r_chisq, double *r_mean,
            double *r_montepicalc, double *r_scc);
void prtEnt(double r_chisq, double r_mean,
            double r_montepicalc, double r_scc);

// -----------------------------------------------------------------------------
// Available RNG&#39;s
// -----------------------------------------------------------------------------

enum eRNG
{
  eRNG_QD1    = 0,           // &#39;Quick and dirty&#39; LCG
  eRNG_MT     = 1,           // Mersenne Twister MT19937_02        (default)
  eRNG_MTHR   = 2,           // &#39;Mother of all RNG&#39; (Marsaglia)
  eRNG_WELL   = 3,           // WELL1024a, single seed with run-in

  eRNG_COUNT  = 4

}; // enum eRNG
// -----------------------------------------------------------------------------
// Description
// -----------------------------------------------------------------------------
//
// The QD1 is fast, but is only as good as an LCG can be,
// it should only be used where true randomness is not required.
// LCG = linear congruential generator.
//
// The other (mt/mthr/well) have been selected after many tests
// using the TestU01 software of Ecuyer and Simard, and pass most
// of the stringent tests for random number generators, failing only
// occasionally at a significance level of a few parts in 0.001.
// They all have extremely long periods and are recommended for any
// serious simulation work requiring many millions of random numbers.
//
// The default generator is MT19937_02.
//
// The acronym WELL means &#39;Well Equidistributed Long-period Linear&#39;
// The generator WELL1024a has been modified to:
//   - initialize with a single seed
//   - generate equidistributed initial values
//   - run for 50,000 numbers to escape from the initial setup
//
// The generators mt/mthr are initialized from a single seed using a WELL.
//
// Speed (relative elapsed time for 10,000,000 numbers)
//     qd1      1.00
//     mt       1.25
//     mthr     1.90
//     well     1.41
//
// -----------------------------------------------------------------------------

extern const char *pszRNGGen[eRNG_COUNT];
extern const char *pszRNGGenList;
extern const char *pszRNGGenDefault;
enum eRNG const eRNGGenDefault = eRNG_MT;

// -----------------------------------------------------------------------------
// forward declaration of derived classes
// -----------------------------------------------------------------------------

class cRNG_QD1;
class cRNG_WELL;
class cRNG_Mother;
class cRNG_MT19937;

// -----------------------------------------------------------------------------
// cRNG - base class
// -----------------------------------------------------------------------------

class cRNG
{
  public:
           virtual ~cRNG()
                     { }

                   // set seed
      virtual void set(unsigned int useed) = 0;

                   // generator name
      virtual char *getszRandom() = 0;

                   // next random number
  virtual unsigned int random() = 0;

                   // return random unsigned int, where 0 &lt;= unsigned int &lt; uirange
 virtual unsigned int randomUint(unsigned int urange);

                   // creates an instance of cRNG,
                   // specifying either eRNG or a string identifier pszrng,
                   // if pszgen incorrectly specified creates a cRNG_MT
                   //
                   //        erng        pszrng
                   //     ---------     --------
                   //     eRNG_QD1       &#34;qd1&#34;
                   //     eRNG_MT        &#34;mt&#34;
                   //     eRNG_MTHR      &#34;mthr&#34;
                   //     eRNG_WELL      &#34;well&#34;
                   //
                   // note: the object must be deleted after use

       static cRNG *createRNG(eRNG erng, unsigned int useed);
       static cRNG *createRNG(char *pszrng, unsigned int useed);

         enum eRNG getRNG()
                     { return RNG;}

        const char *getpszGen()
                     { return (const char*)szGen;}

  protected:
              eRNG RNG;
              char szGen[16];
      unsigned int uSeed;

}; // cRNG
// -----------------------------------------------------------------------------

class cRNG_QD1 : public cRNG
{
  public:
                   cRNG_QD1(unsigned int useed=0)
                     { set(useed);}

                   // set
      virtual void set(unsigned int useed);

                   // generator name
      virtual char *getszRandom()
                     { return &#34;QD1&#34;;}

                   // next random number
    virtual
      unsigned int random();

      unsigned int getSeed()
                   { return uSeed;}

  protected:

}; // cRNG_QD1
// -----------------------------------------------------------------------------

class cRNG_WELL : public cRNG
{
  public:
                   cRNG_WELL(unsigned int useed=0)
                     { set(useed);}

                   // set
      virtual void set(unsigned int useed);

                   // generator name
      virtual char *getszRandom()
                     { return &#34;WELL1024u&#34;;}

                   // next random number
    virtual
      unsigned int random();

  protected:
      unsigned int state_i, STATE[32], z0, z1, z2;

}; // cRNG_WELL
// -----------------------------------------------------------------------------

class cRNG_Mother : public cRNG
{
  public:
                   cRNG_Mother(unsigned int useed=0)
                     { set(useed);}

                   // set
      virtual void set(unsigned int useed);

                   // generator name
      virtual char *getszRandom()
                     { return &#34;Mother&#34;;}

                   // next random number
    virtual
      unsigned int random();

  protected:
      unsigned int smthr[4];
            uint64 xm4, xm3, xm2, xm1, mcarry;

}; // cRNG_Mother
// -----------------------------------------------------------------------------

class cRNG_MT19937 : public cRNG
{
  public:
                   cRNG_MT19937(unsigned int useed=0)
                     { set(useed);}

                   // set
      virtual void set(unsigned int useed);

                   // generator name
      virtual char *getszRandom()
                     { return &#34;MT19937&#34;;}

                   // next random number
    virtual
      unsigned int random();

  protected:
      unsigned int mti, U[624];
     unsigned long mag01[2];

         void initBySeed(unsigned int useed);
         void initByArray(unsigned int lenkey, unsigned int key[]);


}; // cRNG_MT19937
// -----------------------------------------------------------------------------
#endif
</code></pre>
    </td>
    
  </tr>
</table>

<script type="text/javascript">
  hljs.highlightBlock(document.getElementById('sourcecode'))
</script>




    </div>
    <footer id="footer">
      

<p style="margin: 0 0 0 0; line-height: 1em;">
  Browse by prefix: &ensp;
  
    <a href="/prefix/0/">0</a>
    <a href="/prefix/2/">2</a>
    <a href="/prefix/3/">3</a>
    <a href="/prefix/4/">4</a>
    <a href="/prefix/6/">6</a>
    <a href="/prefix/7/">7</a>
    <a href="/prefix/8/">8</a>
    <a href="/prefix/9/">9</a>
    <a href="/prefix/W/">W</a>
    <a href="/prefix/a/">a</a>
    <a href="/prefix/b/">b</a>
    <a href="/prefix/c/">c</a>
    <a href="/prefix/d/">d</a>
    <a href="/prefix/e/">e</a>
    <a href="/prefix/f/">f</a>
    <a href="/prefix/g/">g</a>
    <a href="/prefix/h/">h</a>
    <a href="/prefix/i/">i</a>
    <a href="/prefix/j/">j</a>
    <a href="/prefix/k/">k</a>
    <a href="/prefix/l/">l</a>
    <a href="/prefix/lib-/">lib-</a>
    <a href="/prefix/lib3/">lib3</a>
    <a href="/prefix/liba/">liba</a>
    <a href="/prefix/libb/">libb</a>
    <a href="/prefix/libc/">libc</a>
    <a href="/prefix/libd/">libd</a>
    <a href="/prefix/libe/">libe</a>
    <a href="/prefix/libf/">libf</a>
    <a href="/prefix/libg/">libg</a>
    <a href="/prefix/libh/">libh</a>
    <a href="/prefix/libi/">libi</a>
    <a href="/prefix/libj/">libj</a>
    <a href="/prefix/libk/">libk</a>
    <a href="/prefix/libl/">libl</a>
    <a href="/prefix/libm/">libm</a>
    <a href="/prefix/libn/">libn</a>
    <a href="/prefix/libo/">libo</a>
    <a href="/prefix/libp/">libp</a>
    <a href="/prefix/libq/">libq</a>
    <a href="/prefix/libr/">libr</a>
    <a href="/prefix/libs/">libs</a>
    <a href="/prefix/libt/">libt</a>
    <a href="/prefix/libu/">libu</a>
    <a href="/prefix/libv/">libv</a>
    <a href="/prefix/libw/">libw</a>
    <a href="/prefix/libx/">libx</a>
    <a href="/prefix/liby/">liby</a>
    <a href="/prefix/libz/">libz</a>
    <a href="/prefix/m/">m</a>
    <a href="/prefix/n/">n</a>
    <a href="/prefix/o/">o</a>
    <a href="/prefix/p/">p</a>
    <a href="/prefix/q/">q</a>
    <a href="/prefix/r/">r</a>
    <a href="/prefix/s/">s</a>
    <a href="/prefix/t/">t</a>
    <a href="/prefix/u/">u</a>
    <a href="/prefix/v/">v</a>
    <a href="/prefix/w/">w</a>
    <a href="/prefix/x/">x</a>
    <a href="/prefix/y/">y</a>
    <a href="/prefix/z/">z</a>

  &ensp; | &ensp;
  Browse <a href="/list/1/">by page</a>
</p>
<hr />
<div style="position: relative">
<div style="position: absolute; right: 0">
hosted by<br />
<a href="http://www.irill.org">
  <img width="100px"
       style="vertical-align: middle;"
       src="/static/img/irill.png" alt="IRILL" />
</a>
</div>

<p>
  Debsources &mdash; Copyright (C) 2011&ndash;2014 Matthieu Caneill, Stefano
  Zacchiroli, and
  <a href="http://anonscm.debian.org/gitweb/?p=qa/debsources.git;a=blob;f=AUTHORS;hb=HEAD">contributors</a>.
  License:
  <a href="http://www.gnu.org/licenses/agpl.html">GNU AGPLv3</a>.
  <br />
  Hosted source files are available under their own
  <a href="http://www.debian.org/doc/debian-policy/ch-source.html#s-dpkgcopyright">copyright
  and licenses</a>.
  <br />
  Source code: <a href="http://anonscm.debian.org/gitweb/?p=qa/debsources.git">Git</a>.
  Contact: <a href="mailto:info@sources.debian.net">info@sources.debian.net</a>.
  Last update: Thu, 24 Jul 2014 04:15:25 -0000.
</p>
</div>
    </footer>
    
  </body>
</html>