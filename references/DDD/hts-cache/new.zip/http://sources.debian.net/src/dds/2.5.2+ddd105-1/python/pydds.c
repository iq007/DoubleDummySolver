







<!doctype html>
<html>
  <head>
    
  
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/static/css/debian.css" />
    <link rel="stylesheet" type="text/css"
          href="/static/css/base.css" />
    <link rel="shortcut icon"
          href="/static/favicon.ico" />
    <title>File: pydds.c | Debian sources</title>
    

  <link rel="stylesheet"
        href="/javascript/highlight/styles/googlecode.css">
  <script src="/javascript/highlight/highlight.pack.js"></script>
  <link rel="stylesheet" type="text/css"
        href="/static/css/source_file.css" />


  </head>
  <body>
    <header id="header">
      <div id="upperheader">
        <div id="logo">
          <a href="http://debian.org" title="Debian Home"><img src="/static/img/debian-50.png" alt="Debian"></a>
        </div> <!-- end logo -->
        <p class="section"><a href="/">Debsources</a></p>
	<div id="searchbox">
	    <form action="/search/" name="searchform"
        method="post" style="display: inline;">
      <input id="query-1" name="query" placeholder="package name" type="text" value="">
    
    
    <input type="submit" value="Search package" />
  </form>
	    <form name="codesearch" method="get"
		  action="http://codesearch.debian.net/search">
	      <input name="q" value="package:dds "
		     type="text" />
	      <input type="submit" value="Search code" />
	    </form>
	</div>   <!-- end sitetools -->
      </div> <!-- end upperheader -->
      <!--UdmComment-->
      <nav id="navbar">
        <p class="hidecss"><a href="#content">Skip Quicknav</a></p>
        <ul>
          <li><a href="/">Home</a></li>
          <li><a href="/advancedsearch/">Search</a></li>
          <li><a href="/doc/">Documentation</a></li>
          <li><a href="/stats/">Stats</a></li>
          <li><a href="/about/">About</a></li>
        </ul>
      </nav> <!-- end navbar -->
      <p id="breadcrumbs">source / <a href="/src/dds">dds</a> / <a href="/src/dds/2.5.2%2Bddd105-1">2.5.2+ddd105-1</a> / <a href="/src/dds/2.5.2%2Bddd105-1/python">python</a> / pydds.c</p>
    </header> <!-- end header -->
    
    <div id="content">
      


<h2>File: pydds.c</h2>



<script type="text/javascript">
    function toggle(id)
    {
    var elem = document.getElementById(id);
    if(elem.style.display == "none")
      elem.style.display = "block";
    else
      elem.style.display = "none";
    }
  </script>


<div id="pkginfobox" class="pkginfobox_fixed">

  
  <span onclick="toggle('infobox_content')">package info
    <small>(click to toggle)</small></span>
  
  <div id="infobox_content">
    
    <em>dds 2.5.2+ddd105-1</em>
    
    <ul>
      <li>links:
	<a href="http://packages.qa.debian.org/dds"><abbr title="Debian Package Tracking
							   System">PTS</abbr></a>,
	<a href="http://svn.df7cb.de/bridge/dds/trunk"><abbr title="Version Control System">VCS</abbr></a>
	</li>
      <li>area: main</li>
      <li>in suites: jessie, sid</li>
      
        <li>size: 1,552 kB</li>
      
      
        <li><abbr title="source lines of code">sloc</abbr>:
	  
            
              cpp: 8,945; 
            
              ansic: 281; 
            
              python: 89; 
            
              makefile: 87
            
	  
        </li>
      
    </ul>
  </div>
</div>


<table id="file_metadata">
  <tr>
    <td>
    file content (343 lines)
    | permissions: rw-r--r--
    </td>
    <td style="text-align: right;">
    <a href="/src/dds/2.5.2%2Bddd105-1/python">parent folder</a>
    | <a href="/data/main/d/dds/2.5.2+ddd105-1/python/pydds.c">download</a>
    
    | <a href="/sha256/?checksum=bd10f3f7e571aae661e00c4fd60b2be02b46f0c3e051fc2aa86ff4ca278db3ee&amp;page=1">
	  duplicates (2)</a>
    
    </td>
  </tr>
</table>

<table id="codetable">
  <tr>
    <td>
      <pre id="sourceslinenumbers"><a id="L1" href="#L1">1</a><br /><a id="L2" href="#L2">2</a><br /><a id="L3" href="#L3">3</a><br /><a id="L4" href="#L4">4</a><br /><a id="L5" href="#L5">5</a><br /><a id="L6" href="#L6">6</a><br /><a id="L7" href="#L7">7</a><br /><a id="L8" href="#L8">8</a><br /><a id="L9" href="#L9">9</a><br /><a id="L10" href="#L10">10</a><br /><a id="L11" href="#L11">11</a><br /><a id="L12" href="#L12">12</a><br /><a id="L13" href="#L13">13</a><br /><a id="L14" href="#L14">14</a><br /><a id="L15" href="#L15">15</a><br /><a id="L16" href="#L16">16</a><br /><a id="L17" href="#L17">17</a><br /><a id="L18" href="#L18">18</a><br /><a id="L19" href="#L19">19</a><br /><a id="L20" href="#L20">20</a><br /><a id="L21" href="#L21">21</a><br /><a id="L22" href="#L22">22</a><br /><a id="L23" href="#L23">23</a><br /><a id="L24" href="#L24">24</a><br /><a id="L25" href="#L25">25</a><br /><a id="L26" href="#L26">26</a><br /><a id="L27" href="#L27">27</a><br /><a id="L28" href="#L28">28</a><br /><a id="L29" href="#L29">29</a><br /><a id="L30" href="#L30">30</a><br /><a id="L31" href="#L31">31</a><br /><a id="L32" href="#L32">32</a><br /><a id="L33" href="#L33">33</a><br /><a id="L34" href="#L34">34</a><br /><a id="L35" href="#L35">35</a><br /><a id="L36" href="#L36">36</a><br /><a id="L37" href="#L37">37</a><br /><a id="L38" href="#L38">38</a><br /><a id="L39" href="#L39">39</a><br /><a id="L40" href="#L40">40</a><br /><a id="L41" href="#L41">41</a><br /><a id="L42" href="#L42">42</a><br /><a id="L43" href="#L43">43</a><br /><a id="L44" href="#L44">44</a><br /><a id="L45" href="#L45">45</a><br /><a id="L46" href="#L46">46</a><br /><a id="L47" href="#L47">47</a><br /><a id="L48" href="#L48">48</a><br /><a id="L49" href="#L49">49</a><br /><a id="L50" href="#L50">50</a><br /><a id="L51" href="#L51">51</a><br /><a id="L52" href="#L52">52</a><br /><a id="L53" href="#L53">53</a><br /><a id="L54" href="#L54">54</a><br /><a id="L55" href="#L55">55</a><br /><a id="L56" href="#L56">56</a><br /><a id="L57" href="#L57">57</a><br /><a id="L58" href="#L58">58</a><br /><a id="L59" href="#L59">59</a><br /><a id="L60" href="#L60">60</a><br /><a id="L61" href="#L61">61</a><br /><a id="L62" href="#L62">62</a><br /><a id="L63" href="#L63">63</a><br /><a id="L64" href="#L64">64</a><br /><a id="L65" href="#L65">65</a><br /><a id="L66" href="#L66">66</a><br /><a id="L67" href="#L67">67</a><br /><a id="L68" href="#L68">68</a><br /><a id="L69" href="#L69">69</a><br /><a id="L70" href="#L70">70</a><br /><a id="L71" href="#L71">71</a><br /><a id="L72" href="#L72">72</a><br /><a id="L73" href="#L73">73</a><br /><a id="L74" href="#L74">74</a><br /><a id="L75" href="#L75">75</a><br /><a id="L76" href="#L76">76</a><br /><a id="L77" href="#L77">77</a><br /><a id="L78" href="#L78">78</a><br /><a id="L79" href="#L79">79</a><br /><a id="L80" href="#L80">80</a><br /><a id="L81" href="#L81">81</a><br /><a id="L82" href="#L82">82</a><br /><a id="L83" href="#L83">83</a><br /><a id="L84" href="#L84">84</a><br /><a id="L85" href="#L85">85</a><br /><a id="L86" href="#L86">86</a><br /><a id="L87" href="#L87">87</a><br /><a id="L88" href="#L88">88</a><br /><a id="L89" href="#L89">89</a><br /><a id="L90" href="#L90">90</a><br /><a id="L91" href="#L91">91</a><br /><a id="L92" href="#L92">92</a><br /><a id="L93" href="#L93">93</a><br /><a id="L94" href="#L94">94</a><br /><a id="L95" href="#L95">95</a><br /><a id="L96" href="#L96">96</a><br /><a id="L97" href="#L97">97</a><br /><a id="L98" href="#L98">98</a><br /><a id="L99" href="#L99">99</a><br /><a id="L100" href="#L100">100</a><br /><a id="L101" href="#L101">101</a><br /><a id="L102" href="#L102">102</a><br /><a id="L103" href="#L103">103</a><br /><a id="L104" href="#L104">104</a><br /><a id="L105" href="#L105">105</a><br /><a id="L106" href="#L106">106</a><br /><a id="L107" href="#L107">107</a><br /><a id="L108" href="#L108">108</a><br /><a id="L109" href="#L109">109</a><br /><a id="L110" href="#L110">110</a><br /><a id="L111" href="#L111">111</a><br /><a id="L112" href="#L112">112</a><br /><a id="L113" href="#L113">113</a><br /><a id="L114" href="#L114">114</a><br /><a id="L115" href="#L115">115</a><br /><a id="L116" href="#L116">116</a><br /><a id="L117" href="#L117">117</a><br /><a id="L118" href="#L118">118</a><br /><a id="L119" href="#L119">119</a><br /><a id="L120" href="#L120">120</a><br /><a id="L121" href="#L121">121</a><br /><a id="L122" href="#L122">122</a><br /><a id="L123" href="#L123">123</a><br /><a id="L124" href="#L124">124</a><br /><a id="L125" href="#L125">125</a><br /><a id="L126" href="#L126">126</a><br /><a id="L127" href="#L127">127</a><br /><a id="L128" href="#L128">128</a><br /><a id="L129" href="#L129">129</a><br /><a id="L130" href="#L130">130</a><br /><a id="L131" href="#L131">131</a><br /><a id="L132" href="#L132">132</a><br /><a id="L133" href="#L133">133</a><br /><a id="L134" href="#L134">134</a><br /><a id="L135" href="#L135">135</a><br /><a id="L136" href="#L136">136</a><br /><a id="L137" href="#L137">137</a><br /><a id="L138" href="#L138">138</a><br /><a id="L139" href="#L139">139</a><br /><a id="L140" href="#L140">140</a><br /><a id="L141" href="#L141">141</a><br /><a id="L142" href="#L142">142</a><br /><a id="L143" href="#L143">143</a><br /><a id="L144" href="#L144">144</a><br /><a id="L145" href="#L145">145</a><br /><a id="L146" href="#L146">146</a><br /><a id="L147" href="#L147">147</a><br /><a id="L148" href="#L148">148</a><br /><a id="L149" href="#L149">149</a><br /><a id="L150" href="#L150">150</a><br /><a id="L151" href="#L151">151</a><br /><a id="L152" href="#L152">152</a><br /><a id="L153" href="#L153">153</a><br /><a id="L154" href="#L154">154</a><br /><a id="L155" href="#L155">155</a><br /><a id="L156" href="#L156">156</a><br /><a id="L157" href="#L157">157</a><br /><a id="L158" href="#L158">158</a><br /><a id="L159" href="#L159">159</a><br /><a id="L160" href="#L160">160</a><br /><a id="L161" href="#L161">161</a><br /><a id="L162" href="#L162">162</a><br /><a id="L163" href="#L163">163</a><br /><a id="L164" href="#L164">164</a><br /><a id="L165" href="#L165">165</a><br /><a id="L166" href="#L166">166</a><br /><a id="L167" href="#L167">167</a><br /><a id="L168" href="#L168">168</a><br /><a id="L169" href="#L169">169</a><br /><a id="L170" href="#L170">170</a><br /><a id="L171" href="#L171">171</a><br /><a id="L172" href="#L172">172</a><br /><a id="L173" href="#L173">173</a><br /><a id="L174" href="#L174">174</a><br /><a id="L175" href="#L175">175</a><br /><a id="L176" href="#L176">176</a><br /><a id="L177" href="#L177">177</a><br /><a id="L178" href="#L178">178</a><br /><a id="L179" href="#L179">179</a><br /><a id="L180" href="#L180">180</a><br /><a id="L181" href="#L181">181</a><br /><a id="L182" href="#L182">182</a><br /><a id="L183" href="#L183">183</a><br /><a id="L184" href="#L184">184</a><br /><a id="L185" href="#L185">185</a><br /><a id="L186" href="#L186">186</a><br /><a id="L187" href="#L187">187</a><br /><a id="L188" href="#L188">188</a><br /><a id="L189" href="#L189">189</a><br /><a id="L190" href="#L190">190</a><br /><a id="L191" href="#L191">191</a><br /><a id="L192" href="#L192">192</a><br /><a id="L193" href="#L193">193</a><br /><a id="L194" href="#L194">194</a><br /><a id="L195" href="#L195">195</a><br /><a id="L196" href="#L196">196</a><br /><a id="L197" href="#L197">197</a><br /><a id="L198" href="#L198">198</a><br /><a id="L199" href="#L199">199</a><br /><a id="L200" href="#L200">200</a><br /><a id="L201" href="#L201">201</a><br /><a id="L202" href="#L202">202</a><br /><a id="L203" href="#L203">203</a><br /><a id="L204" href="#L204">204</a><br /><a id="L205" href="#L205">205</a><br /><a id="L206" href="#L206">206</a><br /><a id="L207" href="#L207">207</a><br /><a id="L208" href="#L208">208</a><br /><a id="L209" href="#L209">209</a><br /><a id="L210" href="#L210">210</a><br /><a id="L211" href="#L211">211</a><br /><a id="L212" href="#L212">212</a><br /><a id="L213" href="#L213">213</a><br /><a id="L214" href="#L214">214</a><br /><a id="L215" href="#L215">215</a><br /><a id="L216" href="#L216">216</a><br /><a id="L217" href="#L217">217</a><br /><a id="L218" href="#L218">218</a><br /><a id="L219" href="#L219">219</a><br /><a id="L220" href="#L220">220</a><br /><a id="L221" href="#L221">221</a><br /><a id="L222" href="#L222">222</a><br /><a id="L223" href="#L223">223</a><br /><a id="L224" href="#L224">224</a><br /><a id="L225" href="#L225">225</a><br /><a id="L226" href="#L226">226</a><br /><a id="L227" href="#L227">227</a><br /><a id="L228" href="#L228">228</a><br /><a id="L229" href="#L229">229</a><br /><a id="L230" href="#L230">230</a><br /><a id="L231" href="#L231">231</a><br /><a id="L232" href="#L232">232</a><br /><a id="L233" href="#L233">233</a><br /><a id="L234" href="#L234">234</a><br /><a id="L235" href="#L235">235</a><br /><a id="L236" href="#L236">236</a><br /><a id="L237" href="#L237">237</a><br /><a id="L238" href="#L238">238</a><br /><a id="L239" href="#L239">239</a><br /><a id="L240" href="#L240">240</a><br /><a id="L241" href="#L241">241</a><br /><a id="L242" href="#L242">242</a><br /><a id="L243" href="#L243">243</a><br /><a id="L244" href="#L244">244</a><br /><a id="L245" href="#L245">245</a><br /><a id="L246" href="#L246">246</a><br /><a id="L247" href="#L247">247</a><br /><a id="L248" href="#L248">248</a><br /><a id="L249" href="#L249">249</a><br /><a id="L250" href="#L250">250</a><br /><a id="L251" href="#L251">251</a><br /><a id="L252" href="#L252">252</a><br /><a id="L253" href="#L253">253</a><br /><a id="L254" href="#L254">254</a><br /><a id="L255" href="#L255">255</a><br /><a id="L256" href="#L256">256</a><br /><a id="L257" href="#L257">257</a><br /><a id="L258" href="#L258">258</a><br /><a id="L259" href="#L259">259</a><br /><a id="L260" href="#L260">260</a><br /><a id="L261" href="#L261">261</a><br /><a id="L262" href="#L262">262</a><br /><a id="L263" href="#L263">263</a><br /><a id="L264" href="#L264">264</a><br /><a id="L265" href="#L265">265</a><br /><a id="L266" href="#L266">266</a><br /><a id="L267" href="#L267">267</a><br /><a id="L268" href="#L268">268</a><br /><a id="L269" href="#L269">269</a><br /><a id="L270" href="#L270">270</a><br /><a id="L271" href="#L271">271</a><br /><a id="L272" href="#L272">272</a><br /><a id="L273" href="#L273">273</a><br /><a id="L274" href="#L274">274</a><br /><a id="L275" href="#L275">275</a><br /><a id="L276" href="#L276">276</a><br /><a id="L277" href="#L277">277</a><br /><a id="L278" href="#L278">278</a><br /><a id="L279" href="#L279">279</a><br /><a id="L280" href="#L280">280</a><br /><a id="L281" href="#L281">281</a><br /><a id="L282" href="#L282">282</a><br /><a id="L283" href="#L283">283</a><br /><a id="L284" href="#L284">284</a><br /><a id="L285" href="#L285">285</a><br /><a id="L286" href="#L286">286</a><br /><a id="L287" href="#L287">287</a><br /><a id="L288" href="#L288">288</a><br /><a id="L289" href="#L289">289</a><br /><a id="L290" href="#L290">290</a><br /><a id="L291" href="#L291">291</a><br /><a id="L292" href="#L292">292</a><br /><a id="L293" href="#L293">293</a><br /><a id="L294" href="#L294">294</a><br /><a id="L295" href="#L295">295</a><br /><a id="L296" href="#L296">296</a><br /><a id="L297" href="#L297">297</a><br /><a id="L298" href="#L298">298</a><br /><a id="L299" href="#L299">299</a><br /><a id="L300" href="#L300">300</a><br /><a id="L301" href="#L301">301</a><br /><a id="L302" href="#L302">302</a><br /><a id="L303" href="#L303">303</a><br /><a id="L304" href="#L304">304</a><br /><a id="L305" href="#L305">305</a><br /><a id="L306" href="#L306">306</a><br /><a id="L307" href="#L307">307</a><br /><a id="L308" href="#L308">308</a><br /><a id="L309" href="#L309">309</a><br /><a id="L310" href="#L310">310</a><br /><a id="L311" href="#L311">311</a><br /><a id="L312" href="#L312">312</a><br /><a id="L313" href="#L313">313</a><br /><a id="L314" href="#L314">314</a><br /><a id="L315" href="#L315">315</a><br /><a id="L316" href="#L316">316</a><br /><a id="L317" href="#L317">317</a><br /><a id="L318" href="#L318">318</a><br /><a id="L319" href="#L319">319</a><br /><a id="L320" href="#L320">320</a><br /><a id="L321" href="#L321">321</a><br /><a id="L322" href="#L322">322</a><br /><a id="L323" href="#L323">323</a><br /><a id="L324" href="#L324">324</a><br /><a id="L325" href="#L325">325</a><br /><a id="L326" href="#L326">326</a><br /><a id="L327" href="#L327">327</a><br /><a id="L328" href="#L328">328</a><br /><a id="L329" href="#L329">329</a><br /><a id="L330" href="#L330">330</a><br /><a id="L331" href="#L331">331</a><br /><a id="L332" href="#L332">332</a><br /><a id="L333" href="#L333">333</a><br /><a id="L334" href="#L334">334</a><br /><a id="L335" href="#L335">335</a><br /><a id="L336" href="#L336">336</a><br /><a id="L337" href="#L337">337</a><br /><a id="L338" href="#L338">338</a><br /><a id="L339" href="#L339">339</a><br /><a id="L340" href="#L340">340</a><br /><a id="L341" href="#L341">341</a><br /><a id="L342" href="#L342">342</a><br /><a id="L343" href="#L343">343</a><br /></pre>
    </td>
    <td>
      <pre><code id="sourcecode" class="cpp">#include &#34;Python.h&#34;
#include &#34;structmember.h&#34;
#include &#34;dll.h&#34;

#include &lt;string.h&gt;
#include &lt;stdio.h&gt;

/* type-definition &amp; utility-macros */
struct dealType {
  unsigned short int deal[4][4];
};

typedef struct {
    PyObject_HEAD
    int noOfCards;
    struct dealType deal;
} deal_cell;
staticforward PyTypeObject deal_type;

static char* cardrepr = &#34;AKQJT98765432&#34;;

/*
static int ones(unsigned int m) {
    int result = 0;
    while(m&gt;0) {
        if(m&amp;1) result++;
        m&gt;&gt;=1;
    }
    return result;
}
*/

static void showdist(unsigned int ca[4][4]) {
    int h, s;
    // printf(&#34;SD &#34;);
    for(h=0; h&lt;4; h++) {
        for(s=0; s&lt;4; s++) {
            // printf(&#34;%d&#34;, ones(ca[h][s]));
            // if(s==3) printf(&#34;  &#34;);
            // else printf(&#34;-&#34;);
        }
    }
    // printf(&#34;\n&#34;);
}

static void showdist_short(unsigned short int ca[4][4]) {
    int h, s;
    // printf(&#34;SDS &#34;);
    for(h=0; h&lt;4; h++) {
        for(s=0; s&lt;4; s++) {
            // printf(&#34;%d&#34;, ones(ca[h][s]));
            // if(s==3) printf(&#34;  &#34;);
            // else printf(&#34;-&#34;);
        }
    }
    // printf(&#34;\n&#34;);
}

/* ctor (init) and dtor (dealloc) */
static int
deal_init(PyObject *self, PyObject *args, PyObject *kwds)
{
    static char* nams[] = {&#34;deal&#34;, NULL};
    PyObject* indeal;
    PyObject* seq;
    int i, j, k;

    if(!PyArg_ParseTupleAndKeywords(args, kwds, &#34;O&#34;, nams, &amp;indeal))
        return -1;
    deal_cell *the_deal = (deal_cell*)self;

    seq = PySequence_Fast(indeal, &#34;expected deal -&gt; sequence of 4 hands&#34;);
    if(!seq)
        return -1;
    if(PySequence_Fast_GET_SIZE(seq) != 4) {
        char buf[80];
        sprintf(buf, &#34;expected exactly 4 hands, not %d&#34;,
                PySequence_Fast_GET_SIZE(seq));
        PyErr_SetString(PyExc_ValueError, buf);
        Py_DECREF(seq);
        return -1;
    }

    PyObject** hands = PySequence_Fast_ITEMS(seq);
    PyObject* handseq[4];
    Py_DECREF(seq);
    for(i=0; i&lt;4; i++) {
        PyObject* h = handseq[i] = PySequence_Fast(hands[i], 
                                   &#34;each hand must be a sequence of 4 suits&#34;);
        if(h) {
            if (PySequence_Fast_GET_SIZE(h) != 4) {
                char buf[80];
                sprintf(buf, &#34;expected exactly 4 suits, not %d, for hand %d&#34;,
                        PySequence_Fast_GET_SIZE(h), i);
                PyErr_SetString(PyExc_ValueError, buf);
                Py_DECREF(h);
                handseq[i] = 0;
            }
        }
        if(!handseq[i]) {
            for(j=0; j&lt;i; j++)
                Py_DECREF(handseq[j]);
            return -1;
        }
    }

    int numcards = -1;
    for(i=0; i&lt;4; i++) {
        PyObject* h = handseq[i];
        int nc = 0;
        for(k=0; k&lt;4; k++) {
            PyObject* suit = PySequence_Fast(PySequence_Fast_GET_ITEM(h, k),
                                              &#34;each suit must be seq of cards&#34;);
            if(suit) {
                nc += PySequence_Fast_GET_SIZE(suit);
                Py_DECREF(suit);
            } else {
                for(j=0; j&lt;4; j++)
                    Py_DECREF(handseq[j]);
                return -1;
            }
        }
        if(numcards&gt;=0 &amp;&amp; nc != numcards) {
            char buf[80];
            sprintf(buf, &#34;all hands must have same #cards (%d!=%d at %d)&#34;,
                    numcards, nc, i);
            PyErr_SetString(PyExc_ValueError, buf);
            for(j=0; j&lt;4; j++)
                Py_DECREF(handseq[j]);
            return -1;
        }
        numcards = nc;
    }
    the_deal-&gt;noOfCards = numcards;

    for(i=0; i&lt;4; i++) {
        PyObject* h = handseq[i];
        for(k=0; k&lt;4; k++) {
            PyObject* suit = PySequence_Fast(PySequence_Fast_GET_ITEM(h, k),
                                              &#34;each suit must be SEQ of cards&#34;);
            for(j=0; j&lt;PySequence_Fast_GET_SIZE(suit); j++) {
                PyObject* card = PySequence_Fast_GET_ITEM(suit, j);
                int err = 0;
                if(PyString_Check(card)) {
                    int len = PyString_Size(card);
                    if (len != 1) {
                        char buf[80];
                        sprintf(buf, &#34;cards must have length 1, not %d&#34;, len);
                        PyErr_SetString(PyExc_TypeError, buf);
                        err =1;
                    }
                } else {
                    PyErr_SetString(PyExc_TypeError, &#34;cards must be strings&#34;);
                    err = 1;
                }
                if (!err) {
                    char* c = PyString_AS_STRING(card);
                    char* where = strchr(cardrepr, toupper(c[0]));
                    if (!where) {
                        err = 1;
                    } else {
                        int cod = 14-(where-cardrepr);
                        the_deal-&gt;deal.deal[i][k] |= 1&lt;&lt;cod;
                    }
                }
                if (err) {
                    for(j=0; j&lt;4; j++)
                        Py_DECREF(handseq[j]);
                    Py_DECREF(suit);
                    return -1;
                }
            }
            Py_DECREF(suit);
        }
    }
    showdist_short(the_deal-&gt;deal.deal);

    return 0;
}
static void
deal_dealloc(PyObject *self)
{
    self-&gt;ob_type-&gt;tp_free(self);
}
/* methods */
static PyObject*
deal_str(PyObject *self)
{
    deal_cell* the_deal = (deal_cell*)self;
    int i, j, k;
    char buf[80];
    int ib=0;
    for(i=0; i&lt;4; i++) {
        for(j=0; j&lt;4; j++) {
            int mask = 1&lt;&lt;14;
            for(k=0; k&lt;13; k++) {
                if (the_deal-&gt;deal.deal[i][j] &amp; mask) {
                    buf[ib++] = cardrepr[k];
                }
                mask &gt;&gt;= 1;
            }
            if (j&lt;3) buf[ib++] = &#39; &#39;;
        }
        if (i&lt;3) buf[ib++] = &#39;|&#39;;
    }
    buf[ib]=0;

    return PyString_FromFormat(&#34;deal c%d %s&#34;, the_deal-&gt;noOfCards, buf);
}

static PyObject*
deal_solve(PyObject *self, PyObject *args, PyObject *kwds)
{
    static char* nams[] = {&#34;trump&#34;, &#34;first&#34;, &#34;target&#34;, &#34;solutions&#34;, &#34;mode&#34;, NULL};
    int trump=4, first=1, target=-1, solutions=1, mode=0;
    int i, j;

    if(!PyArg_ParseTupleAndKeywords(args, kwds, &#34;|iiiii&#34;, nams,
            &amp;trump, &amp;first, &amp;target, &amp;solutions, &amp;mode))
        return 0;
    deal_cell* me = (deal_cell*)self;
    struct deal d;
    d.trump = trump;
    d.first = first;
    memset(&amp;(d.currentTrickSuit), 0, 3*sizeof(int));
    memset(&amp;(d.currentTrickRank), 0, 3*sizeof(int));
    for(i=0; i&lt;4; i++)
        for(j=0; j&lt;4; j++)
            d.remainCards[i][j] = me-&gt;deal.deal[i][j];
    showdist(d.remainCards);
// printf(&#34; 4&#34;); fflush(0);
    struct futureTricks futp;
    int status = SolveBoard(d, target, solutions, mode, &amp;futp, 0);
// printf(&#34; 5 %d&#34;, status); fflush(0);
    if (status!=1) {
        char buf[80];
        sprintf(buf, &#34;status: %d&#34;, status);
        PyErr_SetString(PyExc_ValueError, buf);
        return 0;
    }
    PyObject *suit, *rank, *equals, *score;
    int cards = futp.cards;
    suit = PyTuple_New(cards);
    rank = PyTuple_New(cards);
    equals = PyTuple_New(cards);
    score = PyTuple_New(cards);
    for(i=0; i&lt;cards; i++) {
        PyTuple_SET_ITEM(suit, i, PyInt_FromLong(futp.suit[i]));
        PyTuple_SET_ITEM(rank, i, PyInt_FromLong(futp.rank[i]));
        PyTuple_SET_ITEM(equals, i, PyInt_FromLong(futp.equals[i]));
        PyTuple_SET_ITEM(score, i, PyInt_FromLong(futp.score[i]));
    }
    PyObject *result = PyTuple_New(6);
    PyTuple_SET_ITEM(result, 0, PyInt_FromLong(futp.nodes));
    PyTuple_SET_ITEM(result, 1, PyInt_FromLong(futp.cards));
    PyTuple_SET_ITEM(result, 2, suit);
    PyTuple_SET_ITEM(result, 3, rank);
    PyTuple_SET_ITEM(result, 4, equals);
    PyTuple_SET_ITEM(result, 5, score);

    return result;
}

/* members */
static PyMemberDef deal_members[] = {
    {&#34;numcards&#34;, T_INT, offsetof(deal_cell, noOfCards), READONLY, 
                 &#34;number of cards per hand&#34; },
    {NULL}
};

static PyMethodDef deal_methods[] = {
    {&#34;solve&#34;, (PyCFunction)deal_solve, METH_KEYWORDS, &#34;Solve DD play&#34;},
    {0, 0}
};

/* Python type-object */
statichere PyTypeObject deal_type = {
    PyObject_HEAD_INIT(0)    /* initialize to 0 to ensure Win32 portability */
    0,                 /*ob_size*/
    &#34;deal&#34;,            /*tp_name*/
    sizeof(deal_cell), /*tp_basicsize*/
    0,                 /*tp_itemsize*/
    /* methods */
    (destructor)deal_dealloc, /*tp_dealloc*/
    0,                                  /* tp_print */
    0,                                  /* tp_getattr */
    0,                                  /* tp_setattr */
    0,                                  /* tp_compare */
    deal_str,                           /* tp_repr */
    0,                                  /* tp_as_number */
    0,                                  /* tp_as_sequence */
    0,                                  /* tp_as_mapping */
    0,                                  /* tp_hash */
    0,                                  /* tp_call */
    0,                                  /* tp_str */
    PyObject_GenericGetAttr,            /* tp_getattro */
    PyObject_GenericSetAttr,            /* tp_setattro */
    0,                                  /* tp_as_buffer */
    Py_TPFLAGS_DEFAULT,
    &#34;a bridge deal&#34;,
    0,                                  /* tp_traverse */
    0,                                  /* tp_clear */
    0,                                  /* tp_richcompare */
    0,                                  /* tp_weaklistoffset */
    0,                                  /* tp_iter */
    0,                                  /* tp_iternext */
    deal_methods,                       /* tp_methods */
    deal_members,                       /* tp_members */
    0,                                  /* tp_getset */
    0,                                  /* tp_base */
    0,                                  /* tp_dict */
    0,                                  /* tp_descr_get */
    0,                                  /* tp_descr_set */
    0,                                  /* tp_dictoffset */
    deal_init,                          /* tp_init */
    PyType_GenericAlloc,                /* tp_alloc */
    PyType_GenericNew,                  /* tp_new */
    _PyObject_Del,                      /* tp_free */
    /* implied by ISO C: all zeros thereafter */
};

/* module-functions */

static PyMethodDef pydds_methods[] = {
    {0, 0}
};


/* module entry-point (module-initialization) function */
void
initpydds(void)
{
    /* Create the module and add the functions */
    PyObject *m = Py_InitModule(&#34;pydds&#34;, pydds_methods);

    /* Finish initializing the type-objects */
    PyType_Ready(&amp;deal_type);

    PyObject_SetAttrString(m, &#34;deal&#34;, (PyObject*)&amp;deal_type);

    InitStart(1, 1);
}

</code></pre>
    </td>
    
  </tr>
</table>

<script type="text/javascript">
  hljs.highlightBlock(document.getElementById('sourcecode'))
</script>




    </div>
    <footer id="footer">
      

<p style="margin: 0 0 0 0; line-height: 1em;">
  Browse by prefix: &ensp;
  
    <a href="/prefix/0/">0</a>
    <a href="/prefix/2/">2</a>
    <a href="/prefix/3/">3</a>
    <a href="/prefix/4/">4</a>
    <a href="/prefix/6/">6</a>
    <a href="/prefix/7/">7</a>
    <a href="/prefix/8/">8</a>
    <a href="/prefix/9/">9</a>
    <a href="/prefix/W/">W</a>
    <a href="/prefix/a/">a</a>
    <a href="/prefix/b/">b</a>
    <a href="/prefix/c/">c</a>
    <a href="/prefix/d/">d</a>
    <a href="/prefix/e/">e</a>
    <a href="/prefix/f/">f</a>
    <a href="/prefix/g/">g</a>
    <a href="/prefix/h/">h</a>
    <a href="/prefix/i/">i</a>
    <a href="/prefix/j/">j</a>
    <a href="/prefix/k/">k</a>
    <a href="/prefix/l/">l</a>
    <a href="/prefix/lib-/">lib-</a>
    <a href="/prefix/lib3/">lib3</a>
    <a href="/prefix/liba/">liba</a>
    <a href="/prefix/libb/">libb</a>
    <a href="/prefix/libc/">libc</a>
    <a href="/prefix/libd/">libd</a>
    <a href="/prefix/libe/">libe</a>
    <a href="/prefix/libf/">libf</a>
    <a href="/prefix/libg/">libg</a>
    <a href="/prefix/libh/">libh</a>
    <a href="/prefix/libi/">libi</a>
    <a href="/prefix/libj/">libj</a>
    <a href="/prefix/libk/">libk</a>
    <a href="/prefix/libl/">libl</a>
    <a href="/prefix/libm/">libm</a>
    <a href="/prefix/libn/">libn</a>
    <a href="/prefix/libo/">libo</a>
    <a href="/prefix/libp/">libp</a>
    <a href="/prefix/libq/">libq</a>
    <a href="/prefix/libr/">libr</a>
    <a href="/prefix/libs/">libs</a>
    <a href="/prefix/libt/">libt</a>
    <a href="/prefix/libu/">libu</a>
    <a href="/prefix/libv/">libv</a>
    <a href="/prefix/libw/">libw</a>
    <a href="/prefix/libx/">libx</a>
    <a href="/prefix/liby/">liby</a>
    <a href="/prefix/libz/">libz</a>
    <a href="/prefix/m/">m</a>
    <a href="/prefix/n/">n</a>
    <a href="/prefix/o/">o</a>
    <a href="/prefix/p/">p</a>
    <a href="/prefix/q/">q</a>
    <a href="/prefix/r/">r</a>
    <a href="/prefix/s/">s</a>
    <a href="/prefix/t/">t</a>
    <a href="/prefix/u/">u</a>
    <a href="/prefix/v/">v</a>
    <a href="/prefix/w/">w</a>
    <a href="/prefix/x/">x</a>
    <a href="/prefix/y/">y</a>
    <a href="/prefix/z/">z</a>

  &ensp; | &ensp;
  Browse <a href="/list/1/">by page</a>
</p>
<hr />
<div style="position: relative">
<div style="position: absolute; right: 0">
hosted by<br />
<a href="http://www.irill.org">
  <img width="100px"
       style="vertical-align: middle;"
       src="/static/img/irill.png" alt="IRILL" />
</a>
</div>

<p>
  Debsources &mdash; Copyright (C) 2011&ndash;2014 Matthieu Caneill, Stefano
  Zacchiroli, and
  <a href="http://anonscm.debian.org/gitweb/?p=qa/debsources.git;a=blob;f=AUTHORS;hb=HEAD">contributors</a>.
  License:
  <a href="http://www.gnu.org/licenses/agpl.html">GNU AGPLv3</a>.
  <br />
  Hosted source files are available under their own
  <a href="http://www.debian.org/doc/debian-policy/ch-source.html#s-dpkgcopyright">copyright
  and licenses</a>.
  <br />
  Source code: <a href="http://anonscm.debian.org/gitweb/?p=qa/debsources.git">Git</a>.
  Contact: <a href="mailto:info@sources.debian.net">info@sources.debian.net</a>.
  Last update: Thu, 24 Jul 2014 04:15:25 -0000.
</p>
</div>
    </footer>
    
  </body>
</html>