







<!doctype html>
<html>
  <head>
    
  
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css"
          href="/static/css/debian.css" />
    <link rel="stylesheet" type="text/css"
          href="/static/css/base.css" />
    <link rel="shortcut icon"
          href="/static/favicon.ico" />
    <title>File: defs.h | Debian sources</title>
    

  <link rel="stylesheet"
        href="/javascript/highlight/styles/googlecode.css">
  <script src="/javascript/highlight/highlight.pack.js"></script>
  <link rel="stylesheet" type="text/css"
        href="/static/css/source_file.css" />


  </head>
  <body>
    <header id="header">
      <div id="upperheader">
        <div id="logo">
          <a href="http://debian.org" title="Debian Home"><img src="/static/img/debian-50.png" alt="Debian"></a>
        </div> <!-- end logo -->
        <p class="section"><a href="/">Debsources</a></p>
	<div id="searchbox">
	    <form action="/search/" name="searchform"
        method="post" style="display: inline;">
      <input id="query-1" name="query" placeholder="package name" type="text" value="">
    
    
    <input type="submit" value="Search package" />
  </form>
	    <form name="codesearch" method="get"
		  action="http://codesearch.debian.net/search">
	      <input name="q" value="package:dds "
		     type="text" />
	      <input type="submit" value="Search code" />
	    </form>
	</div>   <!-- end sitetools -->
      </div> <!-- end upperheader -->
      <!--UdmComment-->
      <nav id="navbar">
        <p class="hidecss"><a href="#content">Skip Quicknav</a></p>
        <ul>
          <li><a href="/">Home</a></li>
          <li><a href="/advancedsearch/">Search</a></li>
          <li><a href="/doc/">Documentation</a></li>
          <li><a href="/stats/">Stats</a></li>
          <li><a href="/about/">About</a></li>
        </ul>
      </nav> <!-- end navbar -->
      <p id="breadcrumbs">source / <a href="/src/dds">dds</a> / <a href="/src/dds/2.5.2%2Bddd105-1">2.5.2+ddd105-1</a> / <a href="/src/dds/2.5.2%2Bddd105-1/ddd">ddd</a> / defs.h</p>
    </header> <!-- end header -->
    
    <div id="content">
      


<h2>File: defs.h</h2>



<script type="text/javascript">
    function toggle(id)
    {
    var elem = document.getElementById(id);
    if(elem.style.display == "none")
      elem.style.display = "block";
    else
      elem.style.display = "none";
    }
  </script>


<div id="pkginfobox" class="pkginfobox_fixed">

  
  <span onclick="toggle('infobox_content')">package info
    <small>(click to toggle)</small></span>
  
  <div id="infobox_content">
    
    <em>dds 2.5.2+ddd105-1</em>
    
    <ul>
      <li>links:
	<a href="http://packages.qa.debian.org/dds"><abbr title="Debian Package Tracking
							   System">PTS</abbr></a>,
	<a href="http://svn.df7cb.de/bridge/dds/trunk"><abbr title="Version Control System">VCS</abbr></a>
	</li>
      <li>area: main</li>
      <li>in suites: jessie, sid</li>
      
        <li>size: 1,552 kB</li>
      
      
        <li><abbr title="source lines of code">sloc</abbr>:
	  
            
              cpp: 8,945; 
            
              ansic: 281; 
            
              python: 89; 
            
              makefile: 87
            
	  
        </li>
      
    </ul>
  </div>
</div>


<table id="file_metadata">
  <tr>
    <td>
    file content (132 lines)
    | permissions: rw-r--r--
    </td>
    <td style="text-align: right;">
    <a href="/src/dds/2.5.2%2Bddd105-1/ddd">parent folder</a>
    | <a href="/data/main/d/dds/2.5.2+ddd105-1/ddd/defs.h">download</a>
    
    | <a href="/sha256/?checksum=0942d19f664023bbf2130b16afc09061b49b6cc0e06905eaed7e1e9074e9c0af&amp;page=1">
	  duplicates (4)</a>
    
    </td>
  </tr>
</table>

<table id="codetable">
  <tr>
    <td>
      <pre id="sourceslinenumbers"><a id="L1" href="#L1">1</a><br /><a id="L2" href="#L2">2</a><br /><a id="L3" href="#L3">3</a><br /><a id="L4" href="#L4">4</a><br /><a id="L5" href="#L5">5</a><br /><a id="L6" href="#L6">6</a><br /><a id="L7" href="#L7">7</a><br /><a id="L8" href="#L8">8</a><br /><a id="L9" href="#L9">9</a><br /><a id="L10" href="#L10">10</a><br /><a id="L11" href="#L11">11</a><br /><a id="L12" href="#L12">12</a><br /><a id="L13" href="#L13">13</a><br /><a id="L14" href="#L14">14</a><br /><a id="L15" href="#L15">15</a><br /><a id="L16" href="#L16">16</a><br /><a id="L17" href="#L17">17</a><br /><a id="L18" href="#L18">18</a><br /><a id="L19" href="#L19">19</a><br /><a id="L20" href="#L20">20</a><br /><a id="L21" href="#L21">21</a><br /><a id="L22" href="#L22">22</a><br /><a id="L23" href="#L23">23</a><br /><a id="L24" href="#L24">24</a><br /><a id="L25" href="#L25">25</a><br /><a id="L26" href="#L26">26</a><br /><a id="L27" href="#L27">27</a><br /><a id="L28" href="#L28">28</a><br /><a id="L29" href="#L29">29</a><br /><a id="L30" href="#L30">30</a><br /><a id="L31" href="#L31">31</a><br /><a id="L32" href="#L32">32</a><br /><a id="L33" href="#L33">33</a><br /><a id="L34" href="#L34">34</a><br /><a id="L35" href="#L35">35</a><br /><a id="L36" href="#L36">36</a><br /><a id="L37" href="#L37">37</a><br /><a id="L38" href="#L38">38</a><br /><a id="L39" href="#L39">39</a><br /><a id="L40" href="#L40">40</a><br /><a id="L41" href="#L41">41</a><br /><a id="L42" href="#L42">42</a><br /><a id="L43" href="#L43">43</a><br /><a id="L44" href="#L44">44</a><br /><a id="L45" href="#L45">45</a><br /><a id="L46" href="#L46">46</a><br /><a id="L47" href="#L47">47</a><br /><a id="L48" href="#L48">48</a><br /><a id="L49" href="#L49">49</a><br /><a id="L50" href="#L50">50</a><br /><a id="L51" href="#L51">51</a><br /><a id="L52" href="#L52">52</a><br /><a id="L53" href="#L53">53</a><br /><a id="L54" href="#L54">54</a><br /><a id="L55" href="#L55">55</a><br /><a id="L56" href="#L56">56</a><br /><a id="L57" href="#L57">57</a><br /><a id="L58" href="#L58">58</a><br /><a id="L59" href="#L59">59</a><br /><a id="L60" href="#L60">60</a><br /><a id="L61" href="#L61">61</a><br /><a id="L62" href="#L62">62</a><br /><a id="L63" href="#L63">63</a><br /><a id="L64" href="#L64">64</a><br /><a id="L65" href="#L65">65</a><br /><a id="L66" href="#L66">66</a><br /><a id="L67" href="#L67">67</a><br /><a id="L68" href="#L68">68</a><br /><a id="L69" href="#L69">69</a><br /><a id="L70" href="#L70">70</a><br /><a id="L71" href="#L71">71</a><br /><a id="L72" href="#L72">72</a><br /><a id="L73" href="#L73">73</a><br /><a id="L74" href="#L74">74</a><br /><a id="L75" href="#L75">75</a><br /><a id="L76" href="#L76">76</a><br /><a id="L77" href="#L77">77</a><br /><a id="L78" href="#L78">78</a><br /><a id="L79" href="#L79">79</a><br /><a id="L80" href="#L80">80</a><br /><a id="L81" href="#L81">81</a><br /><a id="L82" href="#L82">82</a><br /><a id="L83" href="#L83">83</a><br /><a id="L84" href="#L84">84</a><br /><a id="L85" href="#L85">85</a><br /><a id="L86" href="#L86">86</a><br /><a id="L87" href="#L87">87</a><br /><a id="L88" href="#L88">88</a><br /><a id="L89" href="#L89">89</a><br /><a id="L90" href="#L90">90</a><br /><a id="L91" href="#L91">91</a><br /><a id="L92" href="#L92">92</a><br /><a id="L93" href="#L93">93</a><br /><a id="L94" href="#L94">94</a><br /><a id="L95" href="#L95">95</a><br /><a id="L96" href="#L96">96</a><br /><a id="L97" href="#L97">97</a><br /><a id="L98" href="#L98">98</a><br /><a id="L99" href="#L99">99</a><br /><a id="L100" href="#L100">100</a><br /><a id="L101" href="#L101">101</a><br /><a id="L102" href="#L102">102</a><br /><a id="L103" href="#L103">103</a><br /><a id="L104" href="#L104">104</a><br /><a id="L105" href="#L105">105</a><br /><a id="L106" href="#L106">106</a><br /><a id="L107" href="#L107">107</a><br /><a id="L108" href="#L108">108</a><br /><a id="L109" href="#L109">109</a><br /><a id="L110" href="#L110">110</a><br /><a id="L111" href="#L111">111</a><br /><a id="L112" href="#L112">112</a><br /><a id="L113" href="#L113">113</a><br /><a id="L114" href="#L114">114</a><br /><a id="L115" href="#L115">115</a><br /><a id="L116" href="#L116">116</a><br /><a id="L117" href="#L117">117</a><br /><a id="L118" href="#L118">118</a><br /><a id="L119" href="#L119">119</a><br /><a id="L120" href="#L120">120</a><br /><a id="L121" href="#L121">121</a><br /><a id="L122" href="#L122">122</a><br /><a id="L123" href="#L123">123</a><br /><a id="L124" href="#L124">124</a><br /><a id="L125" href="#L125">125</a><br /><a id="L126" href="#L126">126</a><br /><a id="L127" href="#L127">127</a><br /><a id="L128" href="#L128">128</a><br /><a id="L129" href="#L129">129</a><br /><a id="L130" href="#L130">130</a><br /><a id="L131" href="#L131">131</a><br /><a id="L132" href="#L132">132</a><br /></pre>
    </td>
    <td>
      <pre><code id="sourcecode" class="cpp">/* **************************************************************************
   defs.h    bridge definitions for C/C++ programs
             PM Cronje June 2006

   Copyright 2006 P.M.Cronje

   This file is part of the Double Dummer Driver (DDD).

   DDD is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   DDD is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with DDD; if not, write to the Free Software
   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

   ************************************************************************** */

#ifndef DEFS_H
#define DEFS_H

extern const char *szPLAYER[4];
extern const char  chPLAYER[4];
extern const char *szSUIT[4];
extern const char  chSUIT[4];
extern const char *szCONTRACT[5];
extern const char chCARD[13];

typedef unsigned short int ushort;
typedef unsigned long long int uint64;
typedef unsigned char uchar;

extern const ushort usMASK[16];
extern const ushort usNotMASK[16];
extern const unsigned int ulMASK[32];
extern const unsigned int ulNotMASK[32];

// -----------------------------------------------------------------------------

 int fromHex(char ch);
char toHex(int i);

 int bitCount(ushort m);
 int leastSignificant1Bit(ushort m);
 int mostSignificant1Bit(ushort m);
void clearBit(ushort &amp;m, int ibit);
bool isBit(ushort m, int ibit);
void setBit(ushort &amp;m, int ibit);

char *format64(uint64 number, char sz[]);
char *format(unsigned int number, char sz[]);
char *mPerSec(unsigned int count, double elapsed, char sz[]);

// -----------------------------------------------------------------------------

enum eContract
{

  eCONTRACT_SPADE   =  0,
  eCONTRACT_HEART   =  1,
  eCONTRACT_DIAMOND =  2,
  eCONTRACT_CLUB    =  3,

  eCONTRACT_NOTRUMP =  4,

  eCONTRACT_PASS    =  5,

  eCONTRACT_NONE    =  -1

}; // enum eContract
// -----------------------------------------------------------------------------

enum eContractRisk
{
  eCONTRACTRISK_UNDOUBLED = 0,
  eCONTRACTRISK_DOUBLED   = 1,
  eCONTRACTRISK_REDOUBLED = 2

}; // enum eContractRisk
// -----------------------------------------------------------------------------

enum ePlayer
{
  ePLAYER_WEST  = 0,
  ePLAYER_NORTH = 1,
  ePLAYER_EAST  = 2,
  ePLAYER_SOUTH = 3,

  ePLAYER_NONE  = -1

}; // enum ePlayer
// -----------------------------------------------------------------------------

enum eSuit
{
  eSUIT_SPADE   = 0,
  eSUIT_HEART   = 1,
  eSUIT_DIAMOND = 2,
  eSUIT_CLUB    = 3,

  eSUIT_NONE    = -1

}; // enum eSuit
// -----------------------------------------------------------------------------

enum eCard
{
  eCARD_A        =  0,
  eCARD_K        =  1,
  eCARD_Q        =  2,
  eCARD_J        =  3,
  eCARD_10       =  4,
  eCARD_9        =  5,
  eCARD_8        =  6,
  eCARD_7        =  7,
  eCARD_6        =  8,
  eCARD_5        =  9,
  eCARD_4        = 10,
  eCARD_3        = 11,
  eCARD_2        = 12,

  eCARD_NONE     = -1

}; // enum eCard
// -----------------------------------------------------------------------------
#endif
</code></pre>
    </td>
    
  </tr>
</table>

<script type="text/javascript">
  hljs.highlightBlock(document.getElementById('sourcecode'))
</script>




    </div>
    <footer id="footer">
      

<p style="margin: 0 0 0 0; line-height: 1em;">
  Browse by prefix: &ensp;
  
    <a href="/prefix/0/">0</a>
    <a href="/prefix/2/">2</a>
    <a href="/prefix/3/">3</a>
    <a href="/prefix/4/">4</a>
    <a href="/prefix/6/">6</a>
    <a href="/prefix/7/">7</a>
    <a href="/prefix/8/">8</a>
    <a href="/prefix/9/">9</a>
    <a href="/prefix/W/">W</a>
    <a href="/prefix/a/">a</a>
    <a href="/prefix/b/">b</a>
    <a href="/prefix/c/">c</a>
    <a href="/prefix/d/">d</a>
    <a href="/prefix/e/">e</a>
    <a href="/prefix/f/">f</a>
    <a href="/prefix/g/">g</a>
    <a href="/prefix/h/">h</a>
    <a href="/prefix/i/">i</a>
    <a href="/prefix/j/">j</a>
    <a href="/prefix/k/">k</a>
    <a href="/prefix/l/">l</a>
    <a href="/prefix/lib-/">lib-</a>
    <a href="/prefix/lib3/">lib3</a>
    <a href="/prefix/liba/">liba</a>
    <a href="/prefix/libb/">libb</a>
    <a href="/prefix/libc/">libc</a>
    <a href="/prefix/libd/">libd</a>
    <a href="/prefix/libe/">libe</a>
    <a href="/prefix/libf/">libf</a>
    <a href="/prefix/libg/">libg</a>
    <a href="/prefix/libh/">libh</a>
    <a href="/prefix/libi/">libi</a>
    <a href="/prefix/libj/">libj</a>
    <a href="/prefix/libk/">libk</a>
    <a href="/prefix/libl/">libl</a>
    <a href="/prefix/libm/">libm</a>
    <a href="/prefix/libn/">libn</a>
    <a href="/prefix/libo/">libo</a>
    <a href="/prefix/libp/">libp</a>
    <a href="/prefix/libq/">libq</a>
    <a href="/prefix/libr/">libr</a>
    <a href="/prefix/libs/">libs</a>
    <a href="/prefix/libt/">libt</a>
    <a href="/prefix/libu/">libu</a>
    <a href="/prefix/libv/">libv</a>
    <a href="/prefix/libw/">libw</a>
    <a href="/prefix/libx/">libx</a>
    <a href="/prefix/liby/">liby</a>
    <a href="/prefix/libz/">libz</a>
    <a href="/prefix/m/">m</a>
    <a href="/prefix/n/">n</a>
    <a href="/prefix/o/">o</a>
    <a href="/prefix/p/">p</a>
    <a href="/prefix/q/">q</a>
    <a href="/prefix/r/">r</a>
    <a href="/prefix/s/">s</a>
    <a href="/prefix/t/">t</a>
    <a href="/prefix/u/">u</a>
    <a href="/prefix/v/">v</a>
    <a href="/prefix/w/">w</a>
    <a href="/prefix/x/">x</a>
    <a href="/prefix/y/">y</a>
    <a href="/prefix/z/">z</a>

  &ensp; | &ensp;
  Browse <a href="/list/1/">by page</a>
</p>
<hr />
<div style="position: relative">
<div style="position: absolute; right: 0">
hosted by<br />
<a href="http://www.irill.org">
  <img width="100px"
       style="vertical-align: middle;"
       src="/static/img/irill.png" alt="IRILL" />
</a>
</div>

<p>
  Debsources &mdash; Copyright (C) 2011&ndash;2014 Matthieu Caneill, Stefano
  Zacchiroli, and
  <a href="http://anonscm.debian.org/gitweb/?p=qa/debsources.git;a=blob;f=AUTHORS;hb=HEAD">contributors</a>.
  License:
  <a href="http://www.gnu.org/licenses/agpl.html">GNU AGPLv3</a>.
  <br />
  Hosted source files are available under their own
  <a href="http://www.debian.org/doc/debian-policy/ch-source.html#s-dpkgcopyright">copyright
  and licenses</a>.
  <br />
  Source code: <a href="http://anonscm.debian.org/gitweb/?p=qa/debsources.git">Git</a>.
  Contact: <a href="mailto:info@sources.debian.net">info@sources.debian.net</a>.
  Last update: Thu, 24 Jul 2014 04:15:25 -0000.
</p>
</div>
    </footer>
    
  </body>
</html>